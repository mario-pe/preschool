CREATE PROCEDURE Test(OUT wynik VARCHAR(30))
  BEGIN 
select concat(imie) into wynik from dziecko where id_dziecko = 1; 
END;
