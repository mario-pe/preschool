CREATE PROCEDURE selectUmowa(IN type_p VARCHAR(45), IN date_p TIMESTAMP)
  BEGIN
 select * from umowa where type = type_p COLLATE utf8_unicode_ci and date = date_p COLLATE utf8_unicode_ci;
END;
