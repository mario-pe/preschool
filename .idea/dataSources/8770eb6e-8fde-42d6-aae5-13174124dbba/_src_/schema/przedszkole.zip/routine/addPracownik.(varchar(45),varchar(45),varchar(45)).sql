CREATE PROCEDURE addPracownik(IN imie VARCHAR(45), IN nazwisko VARCHAR(45), IN stanowisko VARCHAR(45))
  BEGIN
 insert into pracownik(imie,nazwisko, stanowisko) values (imie,nazwisko,stanowisko) ;
END;
