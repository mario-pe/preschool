CREATE PROCEDURE editPracownik(IN id INT, IN imie VARCHAR(45), IN nazwisko VARCHAR(45))
  BEGIN
	UPDATE `pracownik` 
	   SET `imie` = imie, 
		   `nazwisko`= nazwisko
	WHERE id_pracownik = id;
END;
