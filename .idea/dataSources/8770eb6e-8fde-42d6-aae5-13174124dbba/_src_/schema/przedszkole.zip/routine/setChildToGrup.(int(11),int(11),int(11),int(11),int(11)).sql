CREATE PROCEDURE setChildToGrup(IN idChild INT, IN idGrupa INT, IN idN INT, IN idO INT, IN idS INT)
  BEGIN
	insert into plan_grupa(id_dziecko,id_grupa,nauczyciele_id,opiekunowie_id,id_sprzataczka) 
    values (idChild,idGrupa,idN,idO,idS);
END;
