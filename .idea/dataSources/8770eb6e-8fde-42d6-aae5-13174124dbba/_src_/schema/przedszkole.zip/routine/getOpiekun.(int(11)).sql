CREATE PROCEDURE getOpiekun(IN id INT)
  BEGIN
	SELECT op.id_opiekun as id, op.imie as imie, op.nazwisko as nazwisko, op.miejscowosc as miejscowosc,
		   op.ulica as ulica, op.dom as dom
    FROM przedszkole.opieka O, przedszkole.opiekun OP
    where o.id_opiekun= op.id_opiekun and o.id_dziecko = id;
END;
