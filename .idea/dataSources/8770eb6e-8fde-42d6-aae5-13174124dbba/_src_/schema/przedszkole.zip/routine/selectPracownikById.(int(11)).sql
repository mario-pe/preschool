CREATE PROCEDURE selectPracownikById(IN idP INT)
  BEGIN
	select p.id_pracownik, p.imie, p.nazwisko, p.stanowisko 
    from pracownik p
    where  p.id_pracownik = idP;
END;
