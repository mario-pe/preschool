CREATE PROCEDURE deleteChildFromZajecia(IN idC INT, IN idZ INT)
  BEGIN
	DELETE FROM `plan_zajec` WHERE `id_dziecko`= idC and `id_zajecia`= idZ;
END;
