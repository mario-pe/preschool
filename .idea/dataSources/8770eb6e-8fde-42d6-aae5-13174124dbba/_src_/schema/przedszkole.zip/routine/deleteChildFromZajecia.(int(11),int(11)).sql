CREATE PROCEDURE deleteChildFromZajecia(IN idC INT, IN idZ INT)
  BEGIN

 delete from `plan_zajec` where `id_dziecko` = idC and `id_zajecia`=idZ;

END;
