CREATE PROCEDURE reltationChildKeeper(IN idChild INT, IN idKeeper INT)
  BEGIN
	insert into przedszkole.opieka (`id_opiekun`,`id_dziecko`) values(idKeeper,idChild);
END;
