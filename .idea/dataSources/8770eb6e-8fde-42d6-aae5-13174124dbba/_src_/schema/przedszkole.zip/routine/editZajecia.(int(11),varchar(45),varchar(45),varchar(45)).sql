CREATE PROCEDURE editZajecia(IN id INT, IN przedmiot VARCHAR(45), IN godzina VARCHAR(45), IN rok VARCHAR(45))
  BEGIN
update `zajecia_dodatkowe`
    SET `przedmiot` = przedmiot,
		`godzina`= godzina,
        `rok_szkolny`= rok
	where id_zajecia = id;
END;
