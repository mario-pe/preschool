CREATE PROCEDURE deletePracownik(IN id INT)
  BEGIN
	
	DELETE FROM `podpisuje` WHERE `id_pracownik`= id;
	DELETE FROM `nauczyciele` WHERE `id_pracownik`= id;
	DELETE FROM `opiekunowie` WHERE `id_pracownik`= id;
	DELETE FROM `nauczyciel` WHERE `id_pracownik`= id;
	DELETE FROM `opiekunka` WHERE `id_pracownik`= id;
	DELETE FROM `sprzataczka` WHERE `id_pracownik`= id;
	DELETE FROM `kucharka` WHERE `id_pracownik`= id;
    DELETE FROM `pracownik` WHERE `id_pracownik`= id;
END;
