CREATE PROCEDURE deletePracownik(IN id INT)
  BEGIN
	DELETE FROM `pracownik` WHERE `id_pracownik`= id;
END;
