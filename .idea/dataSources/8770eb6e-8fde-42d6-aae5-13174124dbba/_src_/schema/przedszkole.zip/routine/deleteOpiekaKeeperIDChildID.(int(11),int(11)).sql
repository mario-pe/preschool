CREATE PROCEDURE deleteOpiekaKeeperIDChildID(IN id INT, IN id_child INT)
  BEGIN
    delete from opieka where id_opiekun = id and id_dziecko = id_child;
END;
