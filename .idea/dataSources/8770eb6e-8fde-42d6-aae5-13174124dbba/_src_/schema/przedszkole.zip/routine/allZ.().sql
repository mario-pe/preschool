CREATE PROCEDURE allZ()
  BEGIN
	select * from zajecia_dodatkowe;
END;
