CREATE PROCEDURE setChildToGrup(IN idChild INT, IN idGrupa INT)
  BEGIN
	insert into plan_grupa(id_dziecko,id_grupa) values (idChild,idGrupa);
END;
