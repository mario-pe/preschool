CREATE PROCEDURE addSprzataczka(IN idP INT)
  BEGIN
 insert into sprzataczka(id_pracownik,id_grupa) values (idP, 999) ;
END;
