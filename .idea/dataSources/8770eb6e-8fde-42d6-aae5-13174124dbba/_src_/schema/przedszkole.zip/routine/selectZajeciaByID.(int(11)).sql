CREATE PROCEDURE selectZajeciaByID(IN idZ INT)
  BEGIN
 select * from zajecia_dodatkowe where id_zajecia = idZ;
END;
