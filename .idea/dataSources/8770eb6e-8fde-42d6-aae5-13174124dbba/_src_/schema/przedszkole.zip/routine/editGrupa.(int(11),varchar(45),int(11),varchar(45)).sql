CREATE PROCEDURE editGrupa(IN ID INT, IN kat VARCHAR(45), IN sala INT, IN rok VARCHAR(45))
  BEGIN
	update `grupa`
    SET `kat_wiekowa` = kat,
		`sala`= sala,
        `rok_szkolny`= rok
	where id_grupa = id;
END;
