CREATE PROCEDURE addKucharka(IN idP INT, IN badania TIMESTAMP)
  BEGIN
 insert into kucharka(id_pracownik,badania) values (idP,badania) ;
END;
