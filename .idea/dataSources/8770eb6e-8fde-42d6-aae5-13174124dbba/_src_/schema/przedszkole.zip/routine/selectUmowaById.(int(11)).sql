CREATE PROCEDURE selectUmowaById(IN id_p INT)
  BEGIN
 select * from umowa where id_umowa = id_p;
END;
