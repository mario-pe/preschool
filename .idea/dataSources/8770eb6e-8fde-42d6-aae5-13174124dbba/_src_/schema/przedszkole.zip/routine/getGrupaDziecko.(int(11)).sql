CREATE PROCEDURE getGrupaDziecko(IN id INT)
  BEGIN
	SELECT g.id_grupa, g.kat_wiekowa, g.sala, g.rok_szkolny
    FROM przedszkole.grupa g, przedszkole.plan_grupa pg
    where g.id_grupa = pg.id_grupa and id_dziecko = id;
END;
