CREATE PROCEDURE addKeeper(IN imie  VARCHAR(45), IN nazwisko VARCHAR(45), IN miejscowosc VARCHAR(45),
                           IN ulica VARCHAR(45), IN dom VARCHAR(45))
  BEGIN
	INSERT INTO `przedszkole`.`opiekun`
    ( `imie`, `nazwisko`, `miejscowosc`, `ulica`, `dom`) 
    VALUES (imie,nazwisko,miejscowosc,ulica,dom);
END;
