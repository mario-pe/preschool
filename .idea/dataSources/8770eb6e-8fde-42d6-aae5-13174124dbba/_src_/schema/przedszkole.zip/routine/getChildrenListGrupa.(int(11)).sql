CREATE PROCEDURE getChildrenListGrupa(IN idG INT)
  BEGIN
select d.id_dziecko, d.imie, d.nazwisko, d.miejscowosc, d.ulica, d.dom   
        from plan_grupa pg, dziecko d 
        where pg.id_grupa = idG and pg.id_dziecko = d.id_dziecko;

END;
