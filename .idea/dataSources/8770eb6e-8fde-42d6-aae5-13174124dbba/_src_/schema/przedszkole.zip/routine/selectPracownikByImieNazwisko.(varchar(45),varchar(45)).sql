CREATE PROCEDURE selectPracownikByImieNazwisko(IN imie VARCHAR(45), IN nazwisko VARCHAR(45))
  BEGIN
	select p.id_pracownik, p.imie, p.nazwisko, p.stanowisko
    from pracownik p
    where  p.imie = imie COLLATE utf8_unicode_ci and p.nazwisko = nazwisko COLLATE utf8_unicode_ci;
END;
