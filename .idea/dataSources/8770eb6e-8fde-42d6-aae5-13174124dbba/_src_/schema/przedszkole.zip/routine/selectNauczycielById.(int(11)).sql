CREATE PROCEDURE selectNauczycielById(IN id INT)
  BEGIN
	select * from pracownik p, nauczyciel n where p.id_pracownik = id and p.id_pracownik = n.id_pracownik;
END;
