CREATE PROCEDURE selectNauczycielByIdZajecia(IN idZ INT)
  BEGIN
	select p.id_pracownik, p.imie, p.nazwisko 
    from pracownik p, plan_zajec pl 
    where  p.id_pracownik = pl.id_nauczyciel and pl.id_zajecia = idZ;
END;
