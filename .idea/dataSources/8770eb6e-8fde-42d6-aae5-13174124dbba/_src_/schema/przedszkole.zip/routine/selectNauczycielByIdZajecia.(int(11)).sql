CREATE PROCEDURE selectNauczycielByIdZajecia(IN idZ INT)
  BEGIN
	select distinct p.id_pracownik, p.imie, p.nazwisko
    from pracownik p,plan_zajec pz, zajecia_dodatkowe zd
    where  p.id_pracownik = pz.id_nauczyciel and pz.id_nauczyciel = zd.id_pracownika and zd.id_zajecia = idZ;
END;
