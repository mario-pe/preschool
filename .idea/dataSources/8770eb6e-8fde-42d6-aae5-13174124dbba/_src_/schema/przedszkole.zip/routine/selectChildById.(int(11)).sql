CREATE PROCEDURE selectChildById(IN idC INT)
  BEGIN

	 select * from dziecko where `id_dziecko` = idC;

END;
