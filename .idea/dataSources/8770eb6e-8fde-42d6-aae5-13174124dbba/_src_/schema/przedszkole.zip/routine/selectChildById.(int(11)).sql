CREATE PROCEDURE selectChildById(IN id INT)
  BEGIN
select * from dziecko where id_dziecko = id;
END;
