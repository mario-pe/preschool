CREATE PROCEDURE addOpiekunka(IN idP INT, IN specjalnosc VARCHAR(45))
  BEGIN
 insert into opiekunka(id_pracownik,specjalnosc) values (idP,specjalnosc) ;
END;
