CREATE PROCEDURE allChildren()
  BEGIN
		select * from dziecko;
END;
