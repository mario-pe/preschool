CREATE PROCEDURE deleteChildFromGroup(IN idC INT, IN idG INT)
  BEGIN

 delete from `plan_grupa` where `id_dziecko` = idC and `id_grupa`=idG;

END;
