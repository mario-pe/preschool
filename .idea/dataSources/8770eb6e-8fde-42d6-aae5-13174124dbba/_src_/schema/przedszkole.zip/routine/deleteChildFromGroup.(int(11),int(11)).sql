CREATE PROCEDURE deleteChildFromGroup(IN idC INT, IN idG INT)
  BEGIN
	DELETE FROM `plan_grupa` WHERE `id_dziecko`= idC and `id_grupa`= idG;
END;
