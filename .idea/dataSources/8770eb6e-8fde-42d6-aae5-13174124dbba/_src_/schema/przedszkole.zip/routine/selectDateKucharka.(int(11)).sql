CREATE PROCEDURE selectDateKucharka(IN id INT)
  BEGIN
select badania from kucharka where id_pracownik = id;
END;
