CREATE PROCEDURE deleteZajecia(IN id INT)
  BEGIN
	DELETE FROM `zajecia_dodatkowe` WHERE `id_zajecia`= id;
END;
