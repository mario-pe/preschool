CREATE PROCEDURE addUmowa(IN type_p VARCHAR(45), IN date_p TIMESTAMP)
  BEGIN
 insert into umowa(type,date) values (type_p,date_p) ;
END;
