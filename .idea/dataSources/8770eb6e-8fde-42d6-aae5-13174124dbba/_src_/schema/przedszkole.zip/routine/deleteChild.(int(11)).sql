CREATE PROCEDURE deleteChild(IN id INT)
  BEGIN
	DELETE FROM `dziecko` WHERE `id_dziecko`= id;
END;
