CREATE PROCEDURE deleteChild(IN id INT)
  BEGIN
	
    DELETE FROM `plan_zajec` WHERE `id_dziecko`= id;
    DELETE FROM `plan_grupa` WHERE `id_dziecko`= id;
    DELETE FROM `opieka` WHERE `id_dziecko`= id;
    DELETE FROM `dziecko` WHERE `id_dziecko`= id;
END;
