CREATE PROCEDURE deleteGrupa(IN id INT)
  BEGIN
	DELETE FROM `grupa` WHERE `id_grupa`= id;
END;
