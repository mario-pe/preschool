CREATE PROCEDURE allGrupy()
  BEGIN
	select * from grupa;
END;
