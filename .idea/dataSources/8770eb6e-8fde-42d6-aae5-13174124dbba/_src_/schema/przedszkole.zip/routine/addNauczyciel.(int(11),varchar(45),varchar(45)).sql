CREATE PROCEDURE addNauczyciel(IN idP INT, IN stopien VARCHAR(45), IN przedmiot VARCHAR(45))
  BEGIN
 insert into nauczyciel(id_pracownik,stopien_zawodowy,przedmiot) values (idP,stopien,przedmiot) ;
END;
