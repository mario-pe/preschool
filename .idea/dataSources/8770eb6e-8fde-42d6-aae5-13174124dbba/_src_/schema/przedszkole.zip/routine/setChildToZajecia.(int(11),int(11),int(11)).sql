CREATE PROCEDURE setChildToZajecia(IN idNauczyciel INT, IN idZajec INT, IN idChild INT)
  BEGIN
	insert into plan_zajec(id_nauczyciel,id_zajecia,id_dziecko) values (idNauczyciel,idZajec,idChild);
END;
