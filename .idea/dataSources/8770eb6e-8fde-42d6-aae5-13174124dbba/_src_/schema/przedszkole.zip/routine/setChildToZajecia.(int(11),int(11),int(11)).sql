CREATE PROCEDURE setChildToZajecia(IN idChild INT, IN idN INT, IN idGrupa INT)
  BEGIN

	insert into plan_zajec(id_nauczyciel,id_dziecko,id_zajecia	) values (idN,idChild,idGrupa);
END;
