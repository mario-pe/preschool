CREATE PROCEDURE allPracownik()
  BEGIN
	select * from pracownik;
END;
