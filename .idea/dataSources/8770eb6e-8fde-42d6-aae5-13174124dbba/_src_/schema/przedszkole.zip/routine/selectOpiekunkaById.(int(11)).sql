CREATE PROCEDURE selectOpiekunkaById(IN id INT)
  BEGIN

select * from pracownik p, opiekunka o where p.id_pracownik = id and p.id_pracownik = o.id_pracownik;
END;
