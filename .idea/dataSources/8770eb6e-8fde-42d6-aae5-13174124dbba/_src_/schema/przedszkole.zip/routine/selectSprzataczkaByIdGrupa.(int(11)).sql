CREATE PROCEDURE selectSprzataczkaByIdGrupa(IN idG INT)
  BEGIN
	select p.id_pracownik, p.imie, p.nazwisko 
    from pracownik p, sprzataczka s
    where  p.id_pracownik = s.id_pracownik and s.id_grupa = idG;
END;
