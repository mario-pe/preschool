CREATE PROCEDURE addPodpisuje(IN idP INT, IN idU INT)
  BEGIN
	INSERT INTO `przedszkole`.`podpisuje`
		(`id_pracownik`,`id_umowa`) VALUES (idP,idU);

END;
