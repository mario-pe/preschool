CREATE PROCEDURE deleteKeeper(IN id INT)
  BEGIN
 delete from `opiekun` where `id_opiekun` = id;
END;
