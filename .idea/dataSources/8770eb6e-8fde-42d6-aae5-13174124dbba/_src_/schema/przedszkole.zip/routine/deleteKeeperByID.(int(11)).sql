CREATE PROCEDURE deleteKeeperByID(IN id INT)
  BEGIN
    delete from opieka where id_opiekun = id;
END;
