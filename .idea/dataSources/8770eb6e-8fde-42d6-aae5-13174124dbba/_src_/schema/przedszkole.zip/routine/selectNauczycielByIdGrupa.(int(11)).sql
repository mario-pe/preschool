CREATE PROCEDURE selectNauczycielByIdGrupa(IN idG INT)
  BEGIN
	select p.id_pracownik, p.imie, p.nazwisko 
    from pracownik p, nauczyciel n, nauczyciele na
    where  p.id_pracownik = n.id_pracownik and n.id_pracownik = na.id_pracownik and na.id_grupa = idG;
END;
