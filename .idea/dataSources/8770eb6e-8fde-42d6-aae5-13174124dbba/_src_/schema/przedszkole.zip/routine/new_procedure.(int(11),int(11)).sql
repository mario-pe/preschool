CREATE PROCEDURE new_procedure(IN idC INT, IN idG INT)
  BEGIN
	DELETE FROM `plan_grupa` WHERE `id_dziecko`= id and `id_grupa`= idG;
END;
