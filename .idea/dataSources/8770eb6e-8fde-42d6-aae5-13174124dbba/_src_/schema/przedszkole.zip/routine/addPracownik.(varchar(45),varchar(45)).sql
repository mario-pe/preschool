CREATE PROCEDURE addPracownik(IN imie VARCHAR(45), IN nazwisko VARCHAR(45))
  BEGIN
	INSERT INTO `przedszkole`.`pracownik`
    ( `imie`, `nazwisko`) 
    VALUES (imie,nazwisko);
END;
