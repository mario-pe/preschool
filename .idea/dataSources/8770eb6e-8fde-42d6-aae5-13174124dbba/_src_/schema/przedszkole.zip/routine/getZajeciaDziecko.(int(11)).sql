CREATE PROCEDURE getZajeciaDziecko(IN id INT)
  BEGIN
	select z.id_zajecia, z.przedmiot, z.godzina, z.rok_szkolny
    from przedszkole.zajecia_dodatkowe z, przedszkole.plan_zajec pz
    where z.id_zajecia = pz.id_zajecia and id_dziecko = id;
    
END;
