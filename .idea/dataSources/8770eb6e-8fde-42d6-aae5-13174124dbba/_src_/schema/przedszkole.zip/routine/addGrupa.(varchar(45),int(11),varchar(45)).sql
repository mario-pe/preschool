CREATE PROCEDURE addGrupa(IN kat VARCHAR(45), IN sala INT, IN rok VARCHAR(45))
  BEGIN
	INSERT INTO `przedszkole`.`grupa`
		(`kat_wiekowa`, `sala`, `rok_szkolny`) VALUES (kat,sala,rok);

END;
