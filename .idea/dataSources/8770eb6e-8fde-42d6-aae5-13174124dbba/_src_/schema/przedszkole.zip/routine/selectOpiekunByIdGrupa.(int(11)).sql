CREATE PROCEDURE selectOpiekunByIdGrupa(IN idG INT)
  BEGIN
	select p.id_pracownik, p.imie, p.nazwisko 
    from pracownik p, opiekunowie o, opiekunka op
    where  p.id_pracownik = op.id_pracownik and op.id_pracownik = o.id_pracownik and o.id_grupa = idG;
END;
