CREATE PROCEDURE selectListUmowaByIdPracownik(IN idP INT)
  BEGIN
	select u.id_umowa, u.type, u.date 
    from umowa u, podpisuje p
    where u.id_umowa = p.id_umowa and p.id_pracownik = idP; 
END;
