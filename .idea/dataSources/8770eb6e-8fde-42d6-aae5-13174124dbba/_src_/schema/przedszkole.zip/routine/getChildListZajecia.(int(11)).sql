CREATE PROCEDURE getChildListZajecia(IN idZ INT)
  BEGIN
	select d.id_dziecko, d.imie, d.nazwisko, d.miejscowosc, d.ulica, d.dom   
        from plan_zajec pz, dziecko d 
        where pz.id_zajecia = idZ and pz.id_dziecko = d.id_dziecko;
END;
