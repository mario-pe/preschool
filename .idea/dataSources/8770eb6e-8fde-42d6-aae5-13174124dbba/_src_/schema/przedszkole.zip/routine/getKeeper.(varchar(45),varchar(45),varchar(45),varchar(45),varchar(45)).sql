CREATE PROCEDURE getKeeper(IN imiep  VARCHAR(45), IN nazwiskop VARCHAR(45), IN miejscowoscp VARCHAR(45),
                           IN ulicap VARCHAR(45), IN domp VARCHAR(45))
  BEGIN
select id_opiekun 
from opiekun 
where  imie = imiep and 
		nazwisko = nazwiskop and
           miejscowosc = miejscowoscp and
           ulica = ulicap and
           dom = domp;
END;
