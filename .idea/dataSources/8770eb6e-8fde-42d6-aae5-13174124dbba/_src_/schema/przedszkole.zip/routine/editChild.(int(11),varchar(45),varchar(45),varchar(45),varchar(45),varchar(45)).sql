CREATE PROCEDURE editChild(IN id    INT, IN imie VARCHAR(45), IN nazwisko VARCHAR(45), IN miejscowosc VARCHAR(45),
                           IN ulica VARCHAR(45), IN dom VARCHAR(45))
  BEGIN
	UPDATE `dziecko` 
	   SET `imie` = imie, 
		   `nazwisko`= nazwisko,
           `miejscowosc`=miejscowosc,
           `ulica`=ulica,
           `dom`=dom
	WHERE id_dziecko = id;
END;
